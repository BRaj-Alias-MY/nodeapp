const express = require("express");
const jwt = require("jsonwebtoken");
const router = express.Router();
const User = require("../models/user");
const mongoose = require("mongoose");
const db = "mongodb://userservice:userpwd1@ds161042.mlab.com:61042/servicesdb";
mongoose.connect(
  db,
  err => {
    if (err) {
      console.error("Eroor" + err);
    } else {
      console.log("Connected to DB");
    }
  }
);

function verifyToken(req, res, next) {
  if (!req.headers.authorization) {
    return res.status(401).send("Unauthorized Request");
  }

  let token = req.headers.authorization.split(" ")[1];
  if (token === "null") {
    return res.status(401).send("Unauthorized Request");
  }
  let playload = jwt.verify(token, "secretKey");
  if (!playload) {
    return res.status(401).send("Unauthorized Request");
  }
  req.userId = playload.subject;
  next();
}
router.get("/", (req, res) => {
  res.send("From APIs Service");
});

router.post("/register", (req, res) => {
  let userData = req.body;
  let user = new User(userData);
  user.save((error, registeredUser) => {
    if (error) {
      console.log(error);
    } else {
      //generate token
      let payload = { subject: registeredUser._id };
      let token = jwt.sign(payload, "secretKey");
      res.status(200).json({ token: token, email: user.email });
    }
  });
});

router.post("/login", (req, res) => {
  let userData = req.body;
  User.findOne({ email: userData.email }, (error, user) => {
    if (error) {
      console.log(error);
    } else {
      if (!user) {
        console.log(user);
        res.status(401).send("Invalid Email");
      } else {
        if (user.password !== userData.password) {
          res.status(401).send("Invalid Password");
        } else {
          //generate token
          let payload = { subject: user._id };
          let token = jwt.sign(payload, "secretKey");
          // res.status(200).send({ token });
          res.status(200).json({ token: token, email: user.email });
        }
      }
    }
  });
});

router.get("/events", verifyToken, (req, res) => {
  let events = [
    {
      _id: "1",
      name: "Bike Festival",
      description: "New byke festival for childern."
    },
    {
      _id: "2",
      name: "Bike Festival",
      description: "New byke festival for childern."
    },
    {
      _id: "3",
      name: "Bike Festival",
      description: "New byke festival for childern."
    }
  ];
  res.json(events);
});

router.get("/special", verifyToken, (req, res) => {
  let events = [
    {
      _id: "11",
      name: "Bike Festival 33",
      description: "New byke festival for childern."
    },
    {
      _id: "22",
      name: "Bike Festival 33",
      description: "New byke festival for childern."
    },
    {
      _id: "33",
      name: "Bike Festival 33",
      description: "New byke festival for childern."
    }
  ];
  res.json(events);
});

module.exports = router;
